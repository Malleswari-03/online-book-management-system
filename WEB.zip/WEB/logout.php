<?php include 'main_header.php'; ?>
<?php include 'header.php'; ?>
<?php
session_start();
session_unset();
session_destroy();
header('Location: login.php'); // Redirect to login page after logout
exit();
?>
<?php include 'footer.php'; ?>