<?php include 'main_header.php'; ?>
<?php include 'header.php'; ?>

<?php
include 'db_connection.php';

$sql = "SELECT * FROM books";
$result = $conn->query($sql);

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>List of Books</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        /* Optional: Add custom styles here */
        .container {
            margin-top: 20px;
        }
    </style>
</head>

<body>
    <div class="container">
        <h1 class="my-4">List of Books</h1>
        <?php
        if ($result->num_rows > 0) {
            echo "<table class='table table-striped'>";
            echo "<thead><tr><th>Title</th><th>Author</th><th>Genre</th><th>Publication Year</th><th>Actions</th></tr></thead>";
            echo "<tbody>";

            while ($row = $result->fetch_assoc()) {
                echo "<tr><td>{$row['title']}</td><td>{$row['author']}</td><td>{$row['genre']}</td><td>{$row['publication_year']}</td>";
                echo "<td><a class='btn btn-primary btn-sm' href='edit_book.php?id={$row['id']}'>Edit</a> | <a class='btn btn-danger btn-sm' href='delete_book.php?id={$row['id']}' onclick='return confirm(\"Are you sure?\")'>Delete</a></td></tr>";
            }

            echo "</tbody>";
            echo "</table>";
        } else {
            echo "<p>No books found</p>";
        }

        $conn->close();
        ?>
    </div>
</body>

</html>
<?php include 'footer.php'; ?>