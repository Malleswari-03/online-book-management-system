<?php include 'main_header.php'; ?>
<?php include 'header.php'; ?>

<?php
include 'db_connection.php';

// Process search query
if (isset($_GET['search'])) {
    $searchTerm = $_GET['search'];

    $sql = "SELECT * FROM books WHERE title LIKE '%$searchTerm%' OR author LIKE '%$searchTerm%' OR genre LIKE '%$searchTerm%' OR publication_year LIKE '%$searchTerm%'";
    $result = $conn->query($sql);

    if ($result && $result->num_rows > 0) {
?>
        <!DOCTYPE html>
        <html lang="en">

        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Search Results</title>
            <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
            <style>
                /* Custom CSS */
                .no-results {
                    margin-top: 20px;
                    padding: 10px;
                    background-color: #f8d7da; /* Light red background */
                    border-color: #f5c6cb; /* Light red border */
                    color: #721c24; /* Dark red text */
                }

                .btn-back {
                    margin-top: 10px;
                }
            </style>
        </head>

        <body>
            <div class="container mt-5">
                <h1>Search Results</h1>
                <?php
                echo "<p>Showing results for: <strong>$searchTerm</strong></p>";
                echo "<div class='list-group'>";
                while ($row = $result->fetch_assoc()) {
                    echo "<a href='view_book.php?id={$row['id']}' class='list-group-item list-group-item-action'>";
                    echo "<h5 class='mb-1'>{$row['title']}</h5>";
                    echo "<p class='mb-1'>Author: {$row['author']}</p>";
                    echo "<p class='mb-1'>Genre: {$row['genre']}</p>";
                    echo "<small>Publication Year: {$row['publication_year']}</small>";
                    echo "</a>";
                }
                echo "</div>";
                ?>
                <a href="list_books.php" class="btn btn-primary mt-3">Back to Book List</a>
            </div>
        </body>

        </html>
<?php
    } else {
        echo '<div class="container mt-5">';
        echo "<div class='alert alert-warning no-results'>No results found for: <strong>$searchTerm</strong></div>";
        echo "<a href='list_books.php' class='btn btn-primary btn-back'>Back to Book List</a>";
        echo '</div>';
    }
    $conn->close();
    exit; // Stop further execution after displaying search results
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Book</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>

<body>
    <div class="container mt-4">
        <h1>Search Books</h1>
        <form method="GET">
            <div class="form-group">
                <label for="searchTerm">Search by Title, Author, Genre, or Publication Year:</label>
                <input type="text" class="form-control" id="searchTerm" name="search" placeholder="Enter search term">
            </div>
            <button type="submit" class="btn btn-primary">Search</button>
        </form>
        
    </div>
</body>

</html>

<?php include 'footer.php'; ?>
