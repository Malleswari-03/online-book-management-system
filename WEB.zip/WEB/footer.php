<footer class="footer fixed-bottom py-2 bg-dark text-white">
    <div class="container text-center">
        <span class="text-muted">Book Management System &copy; <?php echo date('Y'); ?></span>
    </div>
</footer>