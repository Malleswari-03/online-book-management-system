<?php include 'main_header.php'; ?>
<?php include 'header.php'; ?>
<?php
include 'db_connection.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST['id'];
    $new_title = $_POST['title'];
    $new_author = $_POST['author'];
    $new_genre = $_POST['genre'];
    $new_publication_year = $_POST['publication_year'];

    // Update the book details in the database
    $update_sql = "UPDATE books SET title='$new_title', author='$new_author', genre='$new_genre', publication_year='$new_publication_year' WHERE id=$id";

    if ($conn->query($update_sql) === TRUE) {
        echo '<div class="container mt-5">'; // Start container
        echo '<div class="alert alert-success" role="alert">Book updated successfully</div>'; // Success message
        echo '</div>'; // End container
    } else {
        echo '<div class="container mt-5">'; // Start container
        echo '<div class="alert alert-danger" role="alert">Error updating book details: ' . $conn->error . '</div>'; // Error message
        echo '</div>'; // End container
    }
}

$conn->close();
?>
<?php include 'footer.php'; ?>
