<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Book Management System</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        /* Custom CSS styles */
        .navbar-brand img {
            max-height: 50px;
            margin-right: 10px;
        }

        .navbar-right {
            margin-left: auto !important;
        }
    </style>
</head>

<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <a class="navbar-brand" href="#">
            <img src="img/logo.png" alt="Logo">
            Book Management System
        </a>
        <div class="navbar-right">
            <ul class="navbar-nav mr-auto">
                <?php
                session_start();
                if (isset($_SESSION['username'])) {
                    // User is logged in, display "Logout" button
                    echo '<li class="nav-item">
                            <a class="nav-link" href="logout.php">Logout</a>
                        </li>';
                } else {
                    // User is not logged in, display "Login" and "Sign Up" buttons
                    echo '<li class="nav-item">
                            <a class="nav-link" href="login.php">Login</a>
                        </li>';
                    echo '<li class="nav-item">
                            <a class="nav-link" href="signup.php">Sign Up</a>
                        </li>';
                }
                ?>
            </ul>
        </div>
    </nav>
</body>

</html>
