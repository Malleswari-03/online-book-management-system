<?php
include 'db_connection.php';

// Check if the form was submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Sanitize user inputs to prevent SQL injection
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);

    // Validate username and password (add your validation logic here)
    // For example, check if the username and password meet certain criteria

    // Check if the username already exists in the database
    $check_query = "SELECT * FROM users WHERE username='$username'";
    $check_result = $conn->query($check_query);

    if ($check_result->num_rows > 0) {
        // Username already exists, redirect to signup page with error message
        header("Location: signup.php?error=exists");
        exit();
    } else {
        // Hash the password for security
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        // Insert new user into the database
        $insert_query = "INSERT INTO users (username, password) VALUES ('$username', '$hashed_password')";

        if ($conn->query($insert_query) === TRUE) {
            // User successfully registered, redirect to login page with success message
            header("Location: login.php?signup=success");
            exit();
        } else {
            // Error inserting user into database, redirect to signup page with error message
            header("Location: signup.php?error=insert");
            exit();
        }
    }
}

// If the form was not submitted, redirect to signup page
header("Location: signup.php");
exit();
