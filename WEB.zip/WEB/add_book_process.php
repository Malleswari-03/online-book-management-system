<?php include 'main_header.php'; ?>
<?php include 'header.php'; ?>
<?php
include 'db_connection.php';

$title = $_POST['title'];
$author = $_POST['author'];
$genre = $_POST['genre'];
$publication_year = $_POST['publication_year'];

$sql = "INSERT INTO books (title, author, genre, publication_year) VALUES ('$title', '$author', '$genre', '$publication_year')";

echo '<div class="container mt-5">'; // Start container

if ($conn->query($sql) === TRUE) {
    echo '<div class="alert alert-success" role="alert">New book added successfully</div>'; // Success message
} else {
    echo '<div class="alert alert-danger" role="alert">Error: ' . $sql . '<br>' . $conn->error . '</div>'; // Error message
}

echo '</div>'; // End container

$conn->close();
?>

<?php include 'footer.php'; ?>
