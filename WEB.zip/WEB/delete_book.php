<?php include 'main_header.php'; ?>
<?php include 'header.php'; ?>
<?php
include 'db_connection.php';

$id = $_GET['id'];

$sql = "DELETE FROM books WHERE id=$id";

if ($conn->query($sql) === TRUE) {
    echo '<div class="container mt-5">'; // Start container
    echo '<div class="alert alert-success" role="alert">Book deleted successfully</div>'; // Success message
    echo '</div>'; // End container
} else {
    echo '<div class="container mt-5">'; // Start container
    echo '<div class="alert alert-danger" role="alert">Error deleting book: ' . $conn->error . '</div>'; // Error message
    echo '</div>'; // End container
}

$conn->close();
?>

<?php include 'footer.php'; ?>
