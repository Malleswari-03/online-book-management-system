<?php include 'main_header.php'; ?>
<?php include 'header.php'; ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Book Management System</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        .card {
            position: relative;
            border: 2px solid transparent;
            overflow: hidden;
        }

        .card::before {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: radial-gradient(circle, rgba(0, 123, 255, 0.2) 0%, rgba(0, 123, 255, 0) 100%);
            transition: transform 0.5s ease;
            z-index: 1;
        }

        .card:hover::before {
            transform: translate(150%, 150%);
        }

        .card-body {
            position: relative;
            z-index: 2;
        }

        .card-title {
            font-size: 1.25rem;
            font-weight: bold;
            color: #333;
        }

        .card-text {
            font-size: 1rem;
            margin-bottom: 15px;
            color: #555;
        }

        .btn-primary {
            background-color: #007bff;
            border-color: #007bff;
        }

        .btn-primary:hover {
            background-color: #0056b3;
            border-color: #0056b3;
        }
    </style>
</head>

<body>
    <div class="container mt-5">
        <h1 class="mb-4">Book Management System</h1>
        <div class="row">
            <div class="col-md-6">
                <div class="card mb-3">
                    <div class="card-body">
                        <h5 class="card-title">Add New Book</h5>
                        <p class="card-text">Click below to add a new book to the collection.</p>
                        <a href="add_book.php" class="btn btn-primary">Add Book</a>
                    </div>
                </div>
                <div class="card mb-3">
                    <div class="card-body">
                        <h5 class="card-title">View Books</h5>
                        <p class="card-text">Click below to view the list of all books.</p>
                        <a href="list_books.php" class="btn btn-primary">View Books</a>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card mb-3">
                    <div class="card-body">
                        <h5 class="card-title">Search Books</h5>
                        <p class="card-text">Click below to search for books by title, author, genre, or year.</p>
                        <a href="view_book.php" class="btn btn-primary">Search Books</a>
                    </div>
                </div>
                <div class="card mb-3">
                    <div class="card-body">
                        <h5 class="card-title">Edit/Delete Books</h5>
                        <p class="card-text">Click below to edit or delete existing books.</p>
                        <a href="edit_book.php" class="btn btn-primary">Edit/Delete Books</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>

</html>

<?php include 'footer.php'; ?>
